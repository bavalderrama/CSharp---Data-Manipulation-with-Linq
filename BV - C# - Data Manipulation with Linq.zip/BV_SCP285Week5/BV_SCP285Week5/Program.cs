﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BV_SCP285Week5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ##### PROGRAM SHOWCASES ABILITY TO MANIPULATE DATA WITH LINQ #####

            var dow = new[]
            {
                new {id = 0, name = "Mon"},
                new {id = 1, name = "Tue"},
                new {id = 2, name = "Wed"},
                new {id = 3, name = "Thu"},
                new {id = 4, name = "Fri"},
                new {id = 5, name = "Sat"},
                new {id = 6, name = "Sun"},
            };

            var morning = new[]
            {
                new {id = 0, valuem = 45.7f},
                new {id = 1, valuem = 47.8f},
                new {id = 2, valuem = 30.2f},
                new {id = 3, valuem = 32.3f},
                new {id = 4, valuem = 40.4f},
                new {id = 5, valuem = 43.6f},
                new {id = 6, valuem = 52.0f},
            };

            var evening = new[]
            {
                new {id = 0, valuee = 40.2f},
                new {id = 1, valuee = 31.5f},
                new {id = 2, valuee = 35.5f},
                new {id = 3, valuee = 38.6f},
                new {id = 4, valuee = 40.5f},
                new {id = 5, valuee = 43.2f},
                new {id = 6, valuee = 47.1f},
            };

            Console.WriteLine("--------------------ORIGINAL TABLES--------------------");
            Console.WriteLine();
            Console.WriteLine("--------------------Day of the Week--------------------");
            Console.WriteLine("Item ID   Day of the Week");

            foreach (var item in dow)
            {
                Console.WriteLine($"{item.id,4} {item.name,14}");
            }

            Console.WriteLine();
            Console.WriteLine("---------------------Morning Temps---------------------");
            Console.WriteLine("Item ID   Morning Temperature");

            foreach (var item in morning)
            {
                Console.WriteLine($"{item.id,4} {item.valuem,14:F1}");
            }

            Console.WriteLine();
            Console.WriteLine("---------------------Evening Temps---------------------");
            Console.WriteLine("Item ID   Evening Temperature");

            foreach (var item in evening)
            {
                Console.WriteLine($"{item.id,4} {item.valuee,14:F1}");
            }

            var joinedTable1 = from id in dow  // with ID Value
                              join name in morning on id.id equals name.id
                              join value in evening on id.id equals value.id
                              select new { ID = id.id, Name = id.name, Valuem = name.valuem, Valuee = value.valuee};

            Console.WriteLine();
            Console.WriteLine("---------------------COMBINED TABLE---------------------");
            Console.WriteLine("Item ID   Day of the Week   Morning Temp   Evening Temp");
            
            foreach (var item in joinedTable1)  // Printing all values, including ID
            {
                Console.WriteLine($"{item.ID,4} {item.Name,13} {item.Valuem,16:F1} {item.Valuee,17:F1}");
            }

            var joinedTable2 = from id in dow  // WITHOUT ID Value
                               join name in morning on id.id equals name.id
                               join value in evening on id.id equals value.id
                               select new { Name = id.name, Valuem = name.valuem, Valuee = value.valuee };

            Console.WriteLine();
            Console.WriteLine("-----------------MORNING TEMPS ABOVE 40-----------------");
            var filtered1 = // selecting morning values higher than 40.0
                from selection in joinedTable2
                where selection.Valuem > 40.0
                orderby selection.Valuem // ordering by morning temperature
                select selection;

            Console.WriteLine("Day of the Week   Morning Temp   Evening Temp");            
            foreach (var item in filtered1)  // printing filtered values (morning temps higher than 40)
            {
                Console.WriteLine($"{item.Name,8} {item.Valuem,16:F1} {item.Valuee,17:F1}");
            }

            Console.WriteLine();
            Console.WriteLine("--------------------ANY TEMP BELOW 32-------------------");
            var filtered2 = // selecting any temp lower than 32
                from selection in joinedTable2
                where selection.Valuem < 32.0 || selection.Valuee < 32.0
                orderby selection.Name // ordering by day of the week (default, but explicitly called out)
                select selection;

            Console.WriteLine("Day of the Week   Morning Temp   Evening Temp");
            foreach (var item in filtered2)  // printing filtered values (any temp below 32)
            {
                Console.WriteLine($"{item.Name,8} {item.Valuem,16:F1} {item.Valuee,17:F1}");
            }

            Console.WriteLine();
            Console.WriteLine("--------------------DIFF > 5 DEGREES--------------------");
            var filtered3 = // selecting all values from joinedTable2
                from selection in joinedTable2
                select selection;

            Console.WriteLine("Day of the Week   Morning Temp   Evening Temp");
            foreach (var item in filtered3)  // printing values where difference between Morning temp and Evening temp is greater than 5
            {
                if ((Math.Abs(item.Valuee - item.Valuem)) > 5) 
                {
                    Console.WriteLine($"{item.Name,8} {item.Valuem,16:F1} {item.Valuee,17:F1}");
                }
                
            }

            Console.ReadLine(); // so program doesn't close after printing

        }
    }
}
